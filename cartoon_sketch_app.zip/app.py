from flask import Flask, request, send_file, render_template
import cv2
import numpy as np
import io
import os

app = Flask(__name__)

def cartoonize_image(image_path):
    img = cv2.imread(image_path)
    img = cv2.resize(img, (500, 500))

    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    inv_gray = 255 - gray
    blur = cv2.GaussianBlur(inv_gray, (21, 21), 0)
    sketch = cv2.divide(gray, 255 - blur, scale=256)
    sketch_bgr = cv2.cvtColor(sketch, cv2.COLOR_GRAY2BGR)
    return sketch_bgr

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/predict", methods=["POST"])
def predict():
    file = request.files["image"]
    image_path = "temp.jpg"
    file.save(image_path)

    cartoon = cartoonize_image(image_path)

    is_success, buffer = cv2.imencode(".jpg", cartoon)
    io_buf = io.BytesIO(buffer)

    return send_file(io_buf, mimetype='image/jpeg')

if __name__ == "__main__":
    app.run(debug=True)
