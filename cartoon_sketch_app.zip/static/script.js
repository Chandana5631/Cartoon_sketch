document.getElementById("generateBtn").addEventListener("click", async () => {
    const input = document.getElementById("imageInput");
    const file = input.files[0];
    if (!file) return alert("Please choose an image!");

    const spinner = document.getElementById("spinner");
    spinner.style.display = "block";

    const formData = new FormData();
    formData.append("image", file);

    try {
        const response = await fetch("/predict", {
            method: "POST",
            body: formData
        });

        if (!response.ok) throw new Error("Sketch generation failed");

        const blob = await response.blob();
        document.getElementById("originalImage").src = URL.createObjectURL(file);
        document.getElementById("resultImage").src = URL.createObjectURL(blob);
    } catch (err) {
        console.error(err);
        alert("Something went wrong. Check the console.");
    } finally {
        spinner.style.display = "none";
    }
});
